# lambda/contact_form.py - Contact form Lambda function

import json
import boto3
import re
from datetime import datetime
import os


def lambda_handler(event, context):
    print("=== LAMBDA FUNCTION START ===")
    print(f"Event: {json.dumps(event, default=str)}")

    # Initialize SES client
    ses_region = os.environ.get('AWS_REGION', 'us-east-1')
    print(f"SES Region: {ses_region}")

    ses_client = boto3.client('ses', region_name=ses_region)

    # Check environment variables
    from_email = os.environ.get('FROM_EMAIL')
    to_email = os.environ.get('TO_EMAIL')

    print(f"FROM_EMAIL env var: '{from_email}'")
    print(f"TO_EMAIL env var: '{to_email}'")

    if not from_email or not to_email:
        print("ERROR: Missing environment variables!")
        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'success': False, 'message': 'Server configuration error'})
        }

    try:
        # Handle CORS preflight
        if event.get('httpMethod') == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Headers': 'Content-Type',
                    'Access-Control-Allow-Methods': 'POST, OPTIONS'
                },
                'body': ''
            }

        # Parse form data from request body
        body = json.loads(event['body'])
        print(f"Parsed body: {body}")

        # Extract form fields
        name = body.get('name', '').strip()
        email = body.get('email', '').strip()
        company = body.get('company', '').strip()
        role = body.get('role', '').strip()
        subject = body.get('subject', '').strip()
        message = body.get('message', '').strip()

        print(
            f"Form data - Name: '{name}', Email: '{email}', Subject: '{subject}'")

        # Validate required fields
        if not name or not email or not subject or not message:
            print("ERROR: Missing required fields")
            return {
                'statusCode': 400,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'success': False, 'message': 'Missing required fields'})
            }

        # Validate email format
        email_pattern = r'^[^\s@]+@[^\s@]+\.[^\s@]+$'
        if not re.match(email_pattern, email):
            print("ERROR: Invalid email format")
            return {
                'statusCode': 400,
                'headers': {'Access-Control-Allow-Origin': '*'},
                'body': json.dumps({'success': False, 'message': 'Invalid email format'})
            }

        # Create email content
        email_subject = f"Portfolio Contact: {subject}"

        email_body = f"""New contact form submission from your portfolio website!

Name: {name}
Email: {email}
Company: {company or 'Not specified'}
Role: {role or 'Not specified'}
Subject: {subject}

Message:
{message}

---
Submitted: {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}
IP Address: {event.get('requestContext', {}).get('identity', {}).get('sourceIp', 'Unknown')}
"""

        print(f"Email subject: '{email_subject}'")
        print(f"Sending FROM: '{from_email}' TO: '{to_email}'")

        # Send email via SES
        print("=== CALLING SES send_email ===")

        ses_response = ses_client.send_email(
            Source=from_email,
            Destination={
                'ToAddresses': [to_email]
            },
            Message={
                'Subject': {
                    'Data': email_subject,
                    'Charset': 'UTF-8'
                },
                'Body': {
                    'Text': {
                        'Data': email_body,
                        'Charset': 'UTF-8'
                    }
                }
            },
            ReplyToAddresses=[email]
        )

        print(f"=== SES RESPONSE ===")
        print(f"SES Response: {json.dumps(ses_response, default=str)}")
        print(f"MessageId: {ses_response['MessageId']}")

        # Return success response
        return {
            'statusCode': 200,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({
                'success': True,
                'message': 'Thank you for your message! I\'ll get back to you within 24 hours.',
                'messageId': ses_response['MessageId']
            })
        }

    except json.JSONDecodeError as e:
        print(f"JSON Decode Error: {str(e)}")
        return {
            'statusCode': 400,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({'success': False, 'message': 'Invalid request format'})
        }

    except Exception as e:
        print(f"=== ERROR ===")
        print(f"Error type: {type(e).__name__}")
        print(f"Error message: {str(e)}")

        return {
            'statusCode': 500,
            'headers': {'Access-Control-Allow-Origin': '*'},
            'body': json.dumps({
                'success': False,
                'message': 'Server error occurred'
            })
        }
